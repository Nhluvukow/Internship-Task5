# Web Scraper

Scrapes product data from a website and saves it to a CSV file.

## Features
- Fetches data using `BeautifulSoup`.
- Saves results in a structured format.

## Usage
Run the program and specify the target URL in the code.